﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc
{
    public partial class frmCalc : Form
    {
        public frmCalc()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNumero2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float soma;

            soma = valorNumero1 + valorNumero2;
            MessageBox.Show("O resultado da soma é: " + soma);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float subtrair;

            subtrair = valorNumero1 - valorNumero2;
            MessageBox.Show("O resultado da subtração é: " + subtrair);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float dividir;

            dividir = valorNumero1 / valorNumero2;
            MessageBox.Show("O resultado da divisão é: " + dividir);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float multiplicar;

            multiplicar = valorNumero1 * valorNumero2;
            MessageBox.Show("O resultado da multiplicação é: " + multiplicar);
        }
    }
}
