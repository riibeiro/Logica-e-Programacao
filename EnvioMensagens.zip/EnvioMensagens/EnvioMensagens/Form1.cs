﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnvioMensagens
{
    public partial class FmrEnvioMensagem : Form
    {
        public FmrEnvioMensagem()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Bem vindo ao formulário!");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Inteiro foi selecionado");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Os dados foram limpos");
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Os dados serão mostrados");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Inteiro foi alterado");
        }
    }
}