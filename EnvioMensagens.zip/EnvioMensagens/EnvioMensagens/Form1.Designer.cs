﻿namespace EnvioMensagens
{
    partial class FmrEnvioMensagem
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FmrEnvioMensagem));
            this.btnMostrar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.txtBooleano = new System.Windows.Forms.TextBox();
            this.lblBooleano = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnMostrar
            // 
            this.btnMostrar.Location = new System.Drawing.Point(71, 375);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(144, 45);
            this.btnMostrar.TabIndex = 0;
            this.btnMostrar.Text = "Mostrar";
            this.btnMostrar.UseVisualStyleBackColor = true;
            this.btnMostrar.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(254, 375);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(144, 45);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblInteiro.Location = new System.Drawing.Point(70, 47);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(69, 22);
            this.lblInteiro.TabIndex = 2;
            this.lblInteiro.Text = "Inteiro";
            this.lblInteiro.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtInteiro
            // 
            this.txtInteiro.Location = new System.Drawing.Point(71, 72);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(327, 29);
            this.txtInteiro.TabIndex = 3;
            this.txtInteiro.TextChanged += new System.EventHandler(this.txtInteiro_TextChanged);
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDecimal.Location = new System.Drawing.Point(67, 121);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(84, 22);
            this.lblDecimal.TabIndex = 4;
            this.lblDecimal.Text = "Decimal";
            // 
            // txtDecimal
            // 
            this.txtDecimal.Location = new System.Drawing.Point(70, 146);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(328, 29);
            this.txtDecimal.TabIndex = 5;
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTexto.Location = new System.Drawing.Point(66, 194);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(62, 22);
            this.lblTexto.TabIndex = 6;
            this.lblTexto.Text = "Texto";
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(70, 219);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(328, 29);
            this.txtTexto.TabIndex = 7;
            // 
            // txtBooleano
            // 
            this.txtBooleano.Location = new System.Drawing.Point(70, 290);
            this.txtBooleano.Name = "txtBooleano";
            this.txtBooleano.Size = new System.Drawing.Size(328, 29);
            this.txtBooleano.TabIndex = 8;
            // 
            // lblBooleano
            // 
            this.lblBooleano.AutoSize = true;
            this.lblBooleano.BackColor = System.Drawing.Color.Transparent;
            this.lblBooleano.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblBooleano.Location = new System.Drawing.Point(66, 265);
            this.lblBooleano.Name = "lblBooleano";
            this.lblBooleano.Size = new System.Drawing.Size(99, 22);
            this.lblBooleano.TabIndex = 9;
            this.lblBooleano.Text = "Booleano";
            // 
            // FmrEnvioMensagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(462, 457);
            this.Controls.Add(this.lblBooleano);
            this.Controls.Add(this.txtBooleano);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnMostrar);
            this.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "FmrEnvioMensagem";
            this.Text = "Envio de Mensagem";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.TextBox txtBooleano;
        private System.Windows.Forms.Label lblBooleano;
    }
}

