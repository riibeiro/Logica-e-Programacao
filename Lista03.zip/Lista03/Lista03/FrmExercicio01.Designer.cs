﻿namespace Lista03
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmExercicio01));
            this.lblRPorcentagem = new System.Windows.Forms.Label();
            this.lblRMedia = new System.Windows.Forms.Label();
            this.lblRSoma = new System.Windows.Forms.Label();
            this.lblExercicio = new System.Windows.Forms.Label();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.btnMedia = new System.Windows.Forms.Button();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblRPorcentagem
            // 
            this.lblRPorcentagem.AutoSize = true;
            this.lblRPorcentagem.Location = new System.Drawing.Point(151, 364);
            this.lblRPorcentagem.Name = "lblRPorcentagem";
            this.lblRPorcentagem.Size = new System.Drawing.Size(121, 13);
            this.lblRPorcentagem.TabIndex = 25;
            this.lblRPorcentagem.Text = "Resultado Porcentagem";
            // 
            // lblRMedia
            // 
            this.lblRMedia.AutoSize = true;
            this.lblRMedia.Location = new System.Drawing.Point(151, 326);
            this.lblRMedia.Name = "lblRMedia";
            this.lblRMedia.Size = new System.Drawing.Size(87, 13);
            this.lblRMedia.TabIndex = 24;
            this.lblRMedia.Text = "Resultado Média";
            // 
            // lblRSoma
            // 
            this.lblRSoma.AutoSize = true;
            this.lblRSoma.Location = new System.Drawing.Point(151, 291);
            this.lblRSoma.Name = "lblRSoma";
            this.lblRSoma.Size = new System.Drawing.Size(85, 13);
            this.lblRSoma.TabIndex = 23;
            this.lblRSoma.Text = "Resultado Soma";
            // 
            // lblExercicio
            // 
            this.lblExercicio.AutoSize = true;
            this.lblExercicio.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio.Location = new System.Drawing.Point(0, 1);
            this.lblExercicio.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblExercicio.Name = "lblExercicio";
            this.lblExercicio.Size = new System.Drawing.Size(134, 31);
            this.lblExercicio.TabIndex = 22;
            this.lblExercicio.Text = "Exercício 01";
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Location = new System.Drawing.Point(599, 218);
            this.btnPorcentagem.Margin = new System.Windows.Forms.Padding(4);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(129, 32);
            this.btnPorcentagem.TabIndex = 21;
            this.btnPorcentagem.Text = "Porcentagem";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Location = new System.Drawing.Point(585, 112);
            this.lblNum3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(35, 13);
            this.lblNum3.TabIndex = 20;
            this.lblNum3.Text = "Num3";
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(589, 149);
            this.txtNum3.Margin = new System.Windows.Forms.Padding(4);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(148, 20);
            this.txtNum3.TabIndex = 19;
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(392, 218);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(4);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(112, 32);
            this.btnMedia.TabIndex = 18;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(369, 113);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(35, 13);
            this.lblNum2.TabIndex = 17;
            this.lblNum2.Text = "Num2";
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(373, 151);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(4);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(148, 20);
            this.txtNum2.TabIndex = 16;
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(169, 218);
            this.btnSoma.Margin = new System.Windows.Forms.Padding(4);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(112, 32);
            this.btnSoma.TabIndex = 15;
            this.btnSoma.Text = "Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(151, 112);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(35, 13);
            this.lblNum1.TabIndex = 14;
            this.lblNum1.Text = "Num1";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(156, 149);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(148, 20);
            this.txtNum1.TabIndex = 13;
            this.txtNum1.TextChanged += new System.EventHandler(this.txtNum1_TextChanged);
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblRPorcentagem);
            this.Controls.Add(this.lblRMedia);
            this.Controls.Add(this.lblRSoma);
            this.Controls.Add(this.lblExercicio);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.txtNum1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmExercicio01";
            this.Text = "Exercicio ";
            this.Load += new System.EventHandler(this.FrmExercicio01_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRPorcentagem;
        private System.Windows.Forms.Label lblRMedia;
        private System.Windows.Forms.Label lblRSoma;
        private System.Windows.Forms.Label lblExercicio;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.TextBox txtNum1;
    }
}