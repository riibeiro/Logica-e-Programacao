﻿namespace Lista03
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmExercicio02));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblExercicio02 = new System.Windows.Forms.Label();
            this.lblVlrPagar = new System.Windows.Forms.Label();
            this.lblVlrLitro = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtVlrPagar = new System.Windows.Forms.TextBox();
            this.txtVlrLitro = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.lblResultado);
            this.panel1.Location = new System.Drawing.Point(5, 314);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(792, 135);
            this.panel1.TabIndex = 0;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblResultado.Location = new System.Drawing.Point(233, 54);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(153, 31);
            this.lblResultado.TabIndex = 0;
            this.lblResultado.Text = "RESULTADO";
            this.lblResultado.Click += new System.EventHandler(this.label5_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.lblExercicio02);
            this.panel2.Location = new System.Drawing.Point(5, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(792, 137);
            this.panel2.TabIndex = 1;
            // 
            // lblExercicio02
            // 
            this.lblExercicio02.AutoSize = true;
            this.lblExercicio02.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio02.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblExercicio02.Location = new System.Drawing.Point(19, 18);
            this.lblExercicio02.Name = "lblExercicio02";
            this.lblExercicio02.Size = new System.Drawing.Size(174, 32);
            this.lblExercicio02.TabIndex = 0;
            this.lblExercicio02.Text = "Exercicio 02";
            this.lblExercicio02.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblVlrPagar
            // 
            this.lblVlrPagar.AutoSize = true;
            this.lblVlrPagar.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrPagar.Location = new System.Drawing.Point(24, 151);
            this.lblVlrPagar.Name = "lblVlrPagar";
            this.lblVlrPagar.Size = new System.Drawing.Size(235, 32);
            this.lblVlrPagar.TabIndex = 2;
            this.lblVlrPagar.Text = "VALOR A PAGAR";
            this.lblVlrPagar.Click += new System.EventHandler(this.lblVlrPagar_Click);
            // 
            // lblVlrLitro
            // 
            this.lblVlrLitro.AutoSize = true;
            this.lblVlrLitro.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrLitro.Location = new System.Drawing.Point(24, 210);
            this.lblVlrLitro.Name = "lblVlrLitro";
            this.lblVlrLitro.Size = new System.Drawing.Size(248, 32);
            this.lblVlrLitro.TabIndex = 3;
            this.lblVlrLitro.Text = "VALOR DO LITRO";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(244, 259);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(189, 39);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtVlrPagar
            // 
            this.txtVlrPagar.Location = new System.Drawing.Point(280, 151);
            this.txtVlrPagar.Multiline = true;
            this.txtVlrPagar.Name = "txtVlrPagar";
            this.txtVlrPagar.Size = new System.Drawing.Size(109, 32);
            this.txtVlrPagar.TabIndex = 5;
            this.txtVlrPagar.TextChanged += new System.EventHandler(this.txtVlrPagar_TextChanged);
            // 
            // txtVlrLitro
            // 
            this.txtVlrLitro.Location = new System.Drawing.Point(280, 210);
            this.txtVlrLitro.Multiline = true;
            this.txtVlrLitro.Name = "txtVlrLitro";
            this.txtVlrLitro.Size = new System.Drawing.Size(109, 32);
            this.txtVlrLitro.TabIndex = 6;
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtVlrLitro);
            this.Controls.Add(this.txtVlrPagar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblVlrLitro);
            this.Controls.Add(this.lblVlrPagar);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmExercicio02";
            this.Text = "Exercicio";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblExercicio02;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblVlrPagar;
        private System.Windows.Forms.Label lblVlrLitro;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtVlrPagar;
        private System.Windows.Forms.TextBox txtVlrLitro;
    }
}