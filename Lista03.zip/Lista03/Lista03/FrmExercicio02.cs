﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void lblVlrPagar_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float vlrPago = float.Parse(txtVlrPagar.Text);
            float vlrLitro = float.Parse(txtVlrLitro.Text);
            float totalLitros;

            totalLitros = vlrPago / vlrLitro;

            lblResultado.Text = "Abasteceu com " + totalLitros.ToString("N2");
        }

        private void txtVlrPagar_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
